<?php

    Class Woo_User_Profile_Picture {


        // =======================================================================================
        // Variable
        private $_size_file = 2097151; // 2MB
        private $_format_file = array(
            'image/jpeg',
            'image/png'
        );


        // =======================================================================================
        // Run [Create Tab - Add style & jquery]
        public function __construct() {

            $this->Create_Tab_my_Profile();

            // Add style & jquery
            function add_style_in_theme2(){
                wp_enqueue_style( 'upp_style', plugins_url( 'css/upp_style.css', __FILE__ ) );
                wp_enqueue_script( 'upp_jquery', plugins_url('js/upp_actions.js', __FILE__) );
            }
            add_action( 'before_form_upload', 'add_style_in_theme2' );

            // Template HTML
            add_action( 'woocommerce_account_profile-picture_endpoint', array($this,'bbloomer_premium_support_content') );

            // save Action Details [when submit 'ClickUploadButton' Click]
            add_action('before_form_upload',array($this,'save_Action'));

        }


        // =======================================================================================
        // Create Tab
        public function Create_Tab_my_Profile() {
            function bbloomer_add_premium_support_endpoint() { add_rewrite_endpoint( 'profile-picture', EP_ROOT | EP_PAGES ); }
            add_action( 'init', 'bbloomer_add_premium_support_endpoint' );

            function bbloomer_premium_support_query_vars( $vars ) { $vars[] = 'profile-picture'; return $vars; }
            add_filter( 'query_vars', 'bbloomer_premium_support_query_vars', 0 );

            function bbloomer_add_premium_support_link_my_account( $items ) { $items['profile-picture'] = 'Profile Picture'; return $items; }
            add_filter( 'woocommerce_account_menu_items', 'bbloomer_add_premium_support_link_my_account' );
        }


        // =======================================================================================
        // Template HTML
        public function bbloomer_premium_support_content() {
            ?>

            <?php do_action('before_form_upload'); ?>
                <form method="POST" enctype="multipart/form-data" action="">
                    <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide bgProfileOfUser">
                    <div id="bgOfPlaceHolderAvatar"><?php global $current_user; get_currentuserinfo(); echo get_avatar( $current_user->ID, 120 ); ?></div>
                    <?php do_action('before_upload_inputs'); ?>
                    <label class="profile_picLabel" for="profile_pic"><?php esc_html_e( 'Upload Profile Picture (Max 2MB)', 'woocommerce' ); ?></label>
                    <div id="btnToOpen"><?php esc_html_e( 'Select a picture', 'woocommerce' ); ?></div>
                    <div id="nameOfFileClick"></div>
                    <input style="visibility: hidden;" type="file" class="woocommerce-Input woocommerce-Input--text input-text" name="profile_pic" id="profile_pic" />
                    <div style="clear:both;"></div>
                    <?php do_action('after_upload_inputs'); ?>
                    <button id="ClickUploadButton" name="ClickUploadButton" type="submit"><?php esc_html_e( 'Save changes', 'woocommerce' ); ?></button>
                    </p>
                </form>
            <?php do_action('after_form_upload'); ?>

            <?php
        }


        // =======================================================================================
        // save Action Details [when submit 'ClickUploadButton' Click]
        public function save_Action() {

            if( isset($_POST['ClickUploadButton']) ){
                $get_File = $_FILES['profile_pic'];

                // Check Format
                if( in_array( $get_File['type'], $this->_format_file) ){
                    // Check Size
                    if( $get_File['size'] < $this->_size_file ){

                        $get_pic_id = $this->upload_Funcs( $get_File );
                        if( isset($get_pic_id) && ($get_pic_id > 0) && is_numeric($get_pic_id) ){
                            echo return_style_error( true, 'Image successfully uploaded');
                        }else{
                            echo return_style_error( false, 'Error uploading image');
                        }

                    }else{
                        echo return_style_error( false, 'The file size is greater than the limit (2MB)');
                    }
                }else{
                    echo return_style_error( false, 'File format is illegal');
                }

            }
        }


        // =======================================================================================
        // Upload Image
        public function upload_Funcs( $file ) {
            $picture_id = 0;
            $wordpress_upload_dir = wp_upload_dir();
            $i = 1;
            $profilepicture = $file;
            $new_file_path = $wordpress_upload_dir['path'] . '/' . $profilepicture['name'];
            $new_file_mime = $profilepicture['type'];

            while( file_exists( $new_file_path ) ) {
                $i++;
                $new_file_path = $wordpress_upload_dir['path'] . '/' . $i . '_' . $profilepicture['name'];
            }

            if( move_uploaded_file( $profilepicture['tmp_name'], $new_file_path ) ) {
                $upload_id = wp_insert_attachment( array(
                    'guid'           => $new_file_path,
                    'post_mime_type' => $new_file_mime,
                    'post_title'     => preg_replace( '/\.[^.]+$/', '', $profilepicture['name'] ),
                    'post_content'   => '',
                    'post_status'    => 'inherit'
                ), $new_file_path );

                // wp_generate_attachment_metadata() won't work if you do not include this file
                require_once(ABSPATH . "wp-admin" . '/includes/image.php');
                require_once(ABSPATH . "wp-admin" . '/includes/file.php');
                require_once(ABSPATH . "wp-admin" . '/includes/media.php');

                wp_update_attachment_metadata( $upload_id, wp_generate_attachment_metadata( $upload_id, $new_file_path ) );
                $picture_id = $upload_id;

                // Update User Meta
                $user_id = get_current_user_id();
                $this->wc_cus_save_profile_pic( $picture_id, $user_id );

                // Return Picture ID To Check Error
                return $picture_id;
            }

        }


        // =======================================================================================
        // Function wc_cus_save_profile_pic
        public function wc_cus_save_profile_pic( $picture_id, $user_id ) {
            update_user_meta( $user_id, 'profile_pic', $picture_id );
        }


        // =======================================================================================
        public function wc_cus_upload_picture( $foto ) {

        }



    }

?>