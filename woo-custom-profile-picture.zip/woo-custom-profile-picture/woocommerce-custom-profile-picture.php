<?php

/*
Plugin Name: Woocommerce Custom Profile Picture
Plugin URI: http://ecomerciar.com/woocommerce-profile-picture
Description: Allows any user to upload their own profile picture to the WooCommerce store
Version: 2.0.0
Author: Ecomerciar, IRPCPRO
Author URI: http://ecomerciar.com , http://irpcpro.ir/
License: GPL2
License URL: http://irpcpro.ir/licenses/gpl.txt
*/


// =========================================================================
// If ABSPATH Defined
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


// =========================================================================
// Alert Function Template
function return_style_error( $type, $text_error ){
    if( $type == false ){
        return '<div class="UPP_Unsuccessful" id="alert_upp_Notic">'.$text_error.'</div>';
    }else{
        return '<div class="UPP_Succeeded" id="alert_upp_Notic">'.$text_error.'</div>';
    }
}


// =========================================================================
// Class Definition & Call
require_once(dirname(__FILE__) . '/class.php');
$newClass = new Woo_User_Profile_Picture();


// =========================================================================
// Function wc_cus_change_avatar
add_filter( 'get_avatar' , 'wc_cus_change_avatar' , 1 , 5 );
function wc_cus_change_avatar( $avatar, $id_or_email, $size, $default, $alt ) {
    $user = false;
    if ( is_numeric( $id_or_email ) ) {
        $id = (int) $id_or_email;
        $user = get_user_by( 'id' , $id );
    } elseif ( is_object( $id_or_email ) ) {
        if ( ! empty( $id_or_email->user_id ) ) {
            $id = (int) $id_or_email->user_id;
            $user = get_user_by( 'id' , $id );
        }
    } else {
        $user = get_user_by( 'email', $id_or_email );	
    }

    if ( $user && is_object( $user ) ) {
		$picture_id = get_user_meta($user->data->ID,'profile_pic');
		if(! empty($picture_id)){
			//$avatar = wp_get_attachment_url( $picture_id[0] );
			$avatar = wp_get_attachment_image_src( $picture_id[0], array($size,$size) )[0]; // Get With Size
			$avatar = "<img alt='{$alt}' src='{$avatar}' class='avatar avatar-{$size} photo' height='{$size}' width='{$size}' />";
		}
    }
    return $avatar;
}
