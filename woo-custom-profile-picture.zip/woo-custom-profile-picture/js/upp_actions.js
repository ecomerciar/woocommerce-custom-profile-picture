﻿$(function(){
    // When Click Open The Input File
    $("#btnToOpen").click(function(){
        $("#profile_pic").click();
    });
    // Get File and Change , Get Name And Show To #nameOfFileClick
    $("#profile_pic").change(function(){
        var fName = $(this).val(),
            sepAll = fName.split("\\");
        $("#nameOfFileClick").text(sepAll[sepAll.length-1]);
    });
});